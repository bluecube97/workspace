package day8;

public class tv_main {

	public static void main(String[] args) {
		// 1. tv 기능 구현 프로그램
		// 2. 채널 up, down, 숫자로 입력
		// 3. 볼륨 up, down
		// 4. 전원 on/off
		tv_controll tc = new tv_controll();

		tc.tv_con();

	}

}
