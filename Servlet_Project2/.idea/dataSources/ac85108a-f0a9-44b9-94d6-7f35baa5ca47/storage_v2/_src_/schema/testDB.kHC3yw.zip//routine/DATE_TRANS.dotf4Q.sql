CREATE
    DEFINER = studyuser@`%` FUNCTION DATE_TRANS(in_date varchar(8)) RETURNS datetime DETERMINISTIC
BEGIN
	RETURN STR_TO_DATE(in_date, '%Y%m%d%H%m%s');
END;

