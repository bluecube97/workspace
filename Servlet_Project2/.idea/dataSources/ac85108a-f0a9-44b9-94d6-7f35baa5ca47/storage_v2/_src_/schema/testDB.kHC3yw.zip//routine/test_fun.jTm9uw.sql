CREATE
    DEFINER = studyuser@`%` FUNCTION test_fun() RETURNS int READS SQL DATA
BEGIN
    DECLARE num INTEGER;

    SELECT COUNT(*)
    INTO num
    FROM testDB.TB_SALES_001NT;
   
    RETURN num;
END;

