package com.test.board.config;

public class Test {
	
	private Number num;
	
	public Test(Number num) {
		this.num = num;
	}

}
