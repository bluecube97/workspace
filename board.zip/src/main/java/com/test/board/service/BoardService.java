package com.test.board.service;

import java.util.List;
import java.util.Map;

public interface BoardService {
	
	List<Map<String, Object>> searchBoard(Map<String, Object> params);
	int countBoard(Map<String, Object> params);
}
