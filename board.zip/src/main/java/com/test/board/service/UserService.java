package com.test.board.service;

import java.util.Map;

public interface UserService {
	Map<String, Object> loginCheck(Map<String, Object> params);
}
