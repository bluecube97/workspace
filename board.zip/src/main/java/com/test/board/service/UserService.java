package com.test.board.service;

import java.util.Map;

public interface UserService {
	boolean loginCheck(Map<String, String> userInfo);
}
