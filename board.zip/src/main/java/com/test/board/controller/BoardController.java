package com.test.board.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.test.board.service.BoardService;

@RequestMapping("/board")
@Controller
public class BoardController {

	@Autowired
	private BoardService boardService;

	@GetMapping("/list")
	public String getBoardList(@RequestParam(value = "keyword", required = false) String keyword,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "size", required = false, defaultValue = "10") int size,
			@RequestParam(value = "bgno", required = false, defaultValue = "5") int bgno, Model model) {
		{
			// 조회 시 페이징 값 셋팅
			Map<String, Object> params = new HashMap<>();
			params.put("sw", keyword);
			int offset = (page - 1) * size;
			params.put("offset", offset);
			params.put("limit", size);
			params.put("bgno", bgno);

			List<Map<String, Object>> boardList = boardService.searchBoard(params);
			int totalRecords = boardService.countBoard(params);
			int totalPages = (int) Math.ceil((double) totalRecords / size);

			// 페이징 계산
			int startPage = ((page - 1) / 10) * 10 + 1;
			int endPage = Math.min(startPage + 9, totalPages);
			boolean hasPrev = startPage > 1;
			boolean hasNext = endPage < totalPages;

			model.addAttribute("boardList", boardList);
			model.addAttribute("keyword", keyword);
			model.addAttribute("currentPage", page);
			model.addAttribute("totalPages", totalPages);
			model.addAttribute("startPage", startPage);
			model.addAttribute("endPage", endPage);
			model.addAttribute("size", size);
			model.addAttribute("hasPrev", hasPrev);
			model.addAttribute("hasNext", hasNext);
			model.addAttribute("bgno", bgno);

			return "boardlist";
		}	
	}
	
	@GetMapping("detail/{id}")
	public String detailView(@PathVariable("id") int id, Model model) {
		System.out.println("id : " + id);
		return "boardDetail";
	}
}
