package com.test.board.controller;

import com.test.board.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping("/login")
	public String showLoginPage() {
		return "login"; // login.jsp
	}

	@PostMapping("/login")
	@ResponseBody
	public Map<String, Object> handleLogin(@RequestBody Map<String, Object> params, HttpSession session) {
		Map<String, Object> response = new HashMap<>();
		Map<String, Object> result = userService.loginCheck(params);

		if (result != null) {
			session.setAttribute("user", result);
			session.setAttribute("user", result);
			response.put("redirect", "/board/list");
		} else {
			response.put("message", "ID, PASSWORD 를 확인하세요");
		}
		return response;
	}
}