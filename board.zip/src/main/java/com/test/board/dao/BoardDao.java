package com.test.board.dao;

import java.util.List;
import java.util.Map;

public interface BoardDao {
	public List<Map<String, String>> getBoardList();
}
