package com.test.board.unity.service;

import java.util.Map;

public interface ConvService {
    Map<String, String> getConv();
}
