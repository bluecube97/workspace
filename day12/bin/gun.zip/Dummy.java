package gun;

public class Dummy {

	public void DummyOutput() {
		
		
	}

}
