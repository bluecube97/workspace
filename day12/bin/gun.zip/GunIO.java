package gun;

public class GunIO {

	public void GunPrint() {

	}

	public void GunInput() {

	}

	public void GunShotInput() {
		
		
	}
}
