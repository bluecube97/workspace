package spring_di.di.inter;

public interface Score {

	public int sum();
	
	public float avg();
	
	public int subjectScore();
}
