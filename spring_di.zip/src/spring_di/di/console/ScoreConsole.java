package spring_di.di.console;

public interface ScoreConsole {
	public void print();
}
