package game;

import java.util.List;

public class status_list {
	

}
